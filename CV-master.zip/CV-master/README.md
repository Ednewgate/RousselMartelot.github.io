File personal_details.tex format:

\newcommand{\phonenumber}{+33 6 77 77 77 77}
\newcommand{\emailaddress}{email@gmail.com}
